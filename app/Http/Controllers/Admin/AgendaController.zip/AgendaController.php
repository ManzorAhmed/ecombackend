<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Agenda;
use DateTime;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Session;
//use Carbon\Carbon;

use Barryvdh\DomPDF\Facade\Pdf;


class AgendaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $obj_user;

    public function __construct(Agenda $userObject)
    {
        $this->middleware('auth:web');
        $this->obj_user = $userObject;
    }
    public function index()
    {
     $Agendas = Agenda::get();
     return view('admin.agendas.index',['title'=>'Registered Agenda List','agenda'=>$Agendas]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.agendas.create', ['title' => 'Create agendas']);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */


    public function store(Request $request)
    {
        $this->validate($request, [
            'hall' => 'required|max:255',
            'color_code' => 'nullable|max:7',
            'image' => 'image|mimes:jpeg,png,jpg'
        ]);

        $input = $request->all();

        $selectedRoom = $input['hall'];

        // Retrieve the last row for the selected room
        $lastRow = Agenda::where('hall', $selectedRoom)
            ->max('row');

        $newRow = $lastRow ? $lastRow + 1 : 1;

        $agenda = new Agenda();
        $agenda->row = $newRow;

        // Set the start_time and end_time fields without using Carbon
        $startTime = DateTime::createFromFormat('H:i', $input['start_time']);
        $endTime = DateTime::createFromFormat('H:i', $input['end_time']);
        $formattedTime = $startTime->format('H:i') . '-' . $endTime->format('H:i');
        $agenda->start_time = $formattedTime;

        // Set the event_date field without using Carbon
        $agenda->event_date = $input['event_date'];

        if (isset($input['track'])) {
            $agenda->track = $input['track'];
        }

        $agenda->hall = $selectedRoom;
        $agenda->session = $input['session'];
        $agenda->chair_speaker = $input['chair_speaker'];
        $agenda->topic = $input['topic'];
        $agenda->ceremony = $input['ceremony'];

        if ($request->filled('color_code')) {
            $agenda->color = $input['color_code'];
        } else {
            $agenda->color = 'default_color'; // Set your default color class here
        }

        if ($request->hasFile('image')) {
            if ($request->file('image')->isValid()) {
                $this->validate($request, [
                    'image' => 'image|mimes:jpeg,png,jpg'
                ]);

                $file = $request->file('image');
                $destinationPath = "uploads/gallery/";
                $extension = $file->getClientOriginalExtension();
                $fileName = $file->getClientOriginalName();
                $fileName = rand() . $fileName;
                $request->file('image')->move($destinationPath, $fileName);
                $agenda->image = $fileName;
            }
        }

        if ($request->filled('hall')) {
            $agenda->save();
            Session::flash('success_message', 'Great! Record has been saved under Agenda successfully!');
        } else {
            Session::flash('error_message', 'Error! Hall field is mandatory.');
        }
        return redirect()->back();
    }



    public function edit($id)
    {
        // Retrieve the agenda data from the database
        $agenda = Agenda::findOrFail($id);

        // Convert the start_time and end_time strings to DateTime instances
        $startTime = null;
        if (!empty($agenda->start_time)) {
            $startTime = DateTime::createFromFormat('H:i', $agenda->start_time);
            if (!$startTime) {
                // Handle invalid time format
                // You can throw an exception, log the error, or set a default value, e.g., $startTime = null;
            }
        }

        $endTime = null;
        if (!empty($agenda->end_time)) {
            $endTime = DateTime::createFromFormat('H:i', $agenda->end_time);
            if (!$endTime) {
                // Handle invalid time format
                // You can throw an exception, log the error, or set a default value, e.g., $endTime = null;
            }
        }

        // Ensure the event_date is in the correct format (Y-m-d)
        $eventDate = null;
        if (!empty($agenda->event_date)) {
            $eventDate = DateTime::createFromFormat('Y-m-d', $agenda->event_date);
            if (!$eventDate) {
                // Handle invalid date format
                // You can throw an exception, log the error, or set a default value, e.g., $eventDate = null;
            } else {
                $eventDate = $eventDate->format('Y-m-d');
            }
        }

        // Pass the agenda data and the start and end times to the view
        return view('admin.agendas.edit', compact('agenda', 'startTime', 'endTime', 'eventDate'));
    }


    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'hall' => 'required|max:255',
            'start_time' => 'required|max:255',
            'end_time' => 'required|max:255',
            'event_date' => 'required|max:255',
            'session' => 'max:865',
            'track' => 'max:255',
            'chair_speaker' => 'max:865',
            'topic' => 'max:865',
            'ceremony' => 'max:865',
            'image' => 'image|mimes:jpeg,png,jpg'
        ]);

        $input = $request->all();

        // Retrieve the existing record from the database
        $agenda = Agenda::find($id);

        if (!$agenda) {
            return redirect()->back()->withErrors(['message' => 'Agenda not found.']);
        }

        // Check if any field is removed or set to an empty value, and update the database accordingly
        if (isset($input['topic']) && $input['topic'] !== $agenda->topic) {
            $agenda->topic = $input['topic'];
        } elseif (!isset($input['topic']) && !empty($agenda->topic)) {
            $agenda->topic = null;
        }

        if (isset($input['ceremony']) && $input['ceremony'] !== $agenda->ceremony) {
            $agenda->ceremony = $input['ceremony'];
        } elseif (!isset($input['ceremony']) && !empty($agenda->ceremony)) {
            $agenda->ceremony = null;
        }

        // Update other fields normally
        $agenda->hall = $input['hall'];
        $startTime = date('H:i', strtotime($input['start_time']));
        $endTime = date('H:i', strtotime($input['end_time']));
        $formattedTime = $startTime . '-' . $endTime;
        $agenda->start_time = $formattedTime;
        $agenda->event_date = date('Y-m-d', strtotime($input['event_date']));

        if (isset($input['track'])) {
            $agenda->track = $input['track'];
        }

        $agenda->session = $input['session'];
        $agenda->chair_speaker = $input['chair_speaker'];

        if ($request->hasFile('image')) {
            if ($request->file('image')->isValid()) {
                $this->validate($request, [
                    'image' => 'image|mimes:jpeg,png,jpg'
                ]);

                $file = $request->file('image');
                $destinationPath = "uploads/gallery/";
                $extension = $file->getClientOriginalExtension();
                $fileName = $file->getClientOriginalName();
                $fileName = rand() . $fileName;
                $request->file('image')->move($destinationPath, $fileName);
                $agenda->image = $fileName;
            }
        }

        $agenda->save();

        Session::flash('success_message', 'Great! Record has been updated successfully!');
        return redirect()->back();
    }



    public function destroy($id)
    {
        $user = $this->obj_user->findOrFail($id);
        $user->delete();
        Session::flash('success_message', 'Agenda Details successfully deleted!');
        return redirect()->route('agenda.index');
    }

    public function deleteSelectedAgenda(Request $request)
    {
        $input = $request->all();
        $this->validate($request, [
            'agenda' => 'required',

        ]);
        foreach ($input['agenda'] as $index => $id) {

            $user = $this->obj_user->findOrFail($id);
            $user->delete();

        }
        Session::flash('success_message', 'Agenda Row successfully deleted!');
        return redirect()->back();

    }
    public function agendaDetail(Request $request)
    {
        $agenda = Agenda::findOrFail($request->input('id'));
        return view('admin.agendas.single', ['title' => 'Agenda Detail', 'agenda' => $agenda]);
    }
}
